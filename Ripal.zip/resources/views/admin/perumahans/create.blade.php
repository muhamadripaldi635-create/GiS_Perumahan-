@extends('layouts.admin')
@section('title', 'Tambah Data Perumahan')
@section('page_title', 'Tambah Data Perumahan')
@section('content')
@include('admin.perumahans._form', ['action' => route('admin.perumahans.store'), 'method' => 'POST', 'submit' => 'Simpan Data Perumahan'])
@endsection

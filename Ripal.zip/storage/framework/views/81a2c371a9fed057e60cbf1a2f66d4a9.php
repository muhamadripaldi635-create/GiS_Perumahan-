<?php $__env->startSection('title', 'Tambah Data Perumahan'); ?>
<?php $__env->startSection('page_title', 'Tambah Data Perumahan'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.perumahans._form', ['action' => route('admin.perumahans.store'), 'method' => 'POST', 'submit' => 'Simpan Data Perumahan'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mypc\Desktop\Joki\Ripal\Laravel\resources\views/admin/perumahans/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Kelola Data Perumahan'); ?>
<?php $__env->startSection('page_title', 'Kelola Data Perumahan'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
    <form class="flex w-full max-w-xl gap-2" method="GET"><input name="q" value="<?php echo e(request('q')); ?>" class="min-w-0 flex-1 rounded-2xl border-line px-4 py-3 text-sm focus:border-blue-600 focus:ring-blue-600" placeholder="Cari nama, alamat, kecamatan, kontak..."><button class="rounded-2xl btn-blue px-5 py-3 text-sm font-black">Cari</button></form>
    <a href="<?php echo e(route('admin.perumahans.create')); ?>" class="rounded-full btn-blue px-5 py-3 text-center text-sm font-black">Tambah Data</a>
</div>
<div class="overflow-hidden rounded-[2rem] border border-line bg-white shadow-zenit">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-line text-sm">
            <thead class="bg-soft text-left text-xs font-black uppercase tracking-wider text-slate-500"><tr><th class="px-5 py-4">Perumahan</th><th class="px-5 py-4">Wilayah</th><th class="px-5 py-4">Kontak</th><th class="px-5 py-4">Risiko</th><th class="px-5 py-4">Status</th><th class="px-5 py-4 text-right">Aksi</th></tr></thead>
            <tbody class="divide-y divide-line">
                <?php $__empty_1 = true; $__currentLoopData = $perumahans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-soft/70 transition"><td class="px-5 py-4"><div class="flex items-center gap-3"><?php if($item->images->first()): ?><img src="<?php echo e(asset('storage/'.$item->images->first()->path)); ?>" class="h-14 w-14 rounded-2xl object-cover"><?php else: ?><div class="grid h-14 w-14 place-items-center rounded-2xl bg-soft text-xs font-black text-slate-400">IMG</div><?php endif; ?><div><p class="font-black"><?php echo e($item->nama); ?></p><p class="mt-1 text-xs font-semibold text-slate-500"><?php echo e($item->jenis_perumahan ?: '-'); ?></p></div></div></td><td class="px-5 py-4"><p class="font-bold"><?php echo e($item->kecamatan ?: '-'); ?></p><p class="mt-1 max-w-[280px] truncate text-xs text-slate-500"><?php echo e($item->alamat ?: '-'); ?></p></td><td class="px-5 py-4"><p class="font-bold"><?php echo e($item->telepon ?: '-'); ?></p><p class="mt-1 text-xs text-slate-500"><?php echo e($item->email ?: '-'); ?></p></td><td class="px-5 py-4"><span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-slate-700"><?php echo e($item->risikos_count); ?> risiko</span></td><td class="px-5 py-4"><span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-blue-700"><?php echo e(ucfirst(str_replace('_',' ', $item->status))); ?></span></td><td class="px-5 py-4"><div class="flex justify-end gap-2"><a href="<?php echo e(route('perumahan.show', $item)); ?>" target="_blank" class="rounded-full border border-line px-3 py-2 text-xs font-black hover:bg-soft">Publik</a><a href="<?php echo e(route('admin.perumahans.edit', $item)); ?>" class="rounded-full bg-ink px-3 py-2 text-xs font-black text-white">Edit</a><form method="POST" action="<?php echo e(route('admin.perumahans.destroy', $item)); ?>" onsubmit="return confirm('Hapus data perumahan ini?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="rounded-full bg-rose-600 px-3 py-2 text-xs font-black text-white">Hapus</button></form></div></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="px-5 py-14 text-center font-bold text-slate-500">Belum ada data perumahan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-5 py-4"><?php echo e($perumahans->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mypc\Desktop\Joki\Ripal\Laravel\resources\views/admin/perumahans/index.blade.php ENDPATH**/ ?>
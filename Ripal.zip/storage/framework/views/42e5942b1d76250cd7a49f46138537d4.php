<?php $__env->startSection('title', 'Tambah Risiko'); ?>
<?php $__env->startSection('page_title', 'Tambah Risiko'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.risikos._form', ['action' => route('admin.risikos.store'), 'method' => 'POST', 'submit' => 'Simpan Risiko'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mypc\Desktop\Joki\Ripal\Laravel\resources\views/admin/risikos/create.blade.php ENDPATH**/ ?>
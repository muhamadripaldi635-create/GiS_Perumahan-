<?php $__env->startSection('title', $perumahan->nama . ' - Detail Perumahan'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $mapsUrl = $perumahan->googleMapsDirectUrl();
    $rupiah = fn ($v) => $v ? 'Rp ' . number_format($v, 0, ',', '.') : '-';
    $statusLabel = ['tersedia' => 'Tersedia', 'proses' => 'Proses', 'terjual' => 'Terjual', 'tidak_aktif' => 'Tidak Aktif'][$perumahan->status] ?? '-';
?>

<section class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
    <a href="<?php echo e(route('home')); ?>#data" class="mb-6 inline-flex items-center gap-2 rounded-full border border-line bg-white px-4 py-2 text-sm font-black text-slate-600 hover:text-blue-600">← Kembali ke Data</a>
    <div class="grid gap-8 lg:grid-cols-[1fr_380px]">
        <main class="space-y-7">
            <div class="overflow-hidden rounded-[2rem] border border-line bg-white shadow-zenit">
                <?php if($perumahan->images->count()): ?>
                    <img src="<?php echo e(asset('storage/' . $perumahan->images->first()->path)); ?>" class="h-[420px] w-full object-cover" alt="<?php echo e($perumahan->nama); ?>">
                <?php else: ?>
                    <div class="grid h-[360px] place-items-center bg-soft text-sm font-black uppercase tracking-wider text-slate-400">Gambar belum tersedia</div>
                <?php endif; ?>
                <div class="p-6 md:p-8">
                    <p class="text-xs font-black uppercase tracking-[.3em] text-blue-600">Detail Perumahan</p>
                    <h1 class="mt-3 text-3xl font-black tracking-tight md:text-5xl"><?php echo e($perumahan->nama); ?></h1>
                    <p class="mt-4 max-w-3xl leading-8 text-slate-600"><?php echo e($perumahan->deskripsi ?: 'Deskripsi perumahan belum tersedia.'); ?></p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        <?php if($mapsUrl): ?><a href="<?php echo e($mapsUrl); ?>" target="_blank" class="rounded-full btn-blue px-5 py-3 text-sm font-black">Buka Google Maps</a><?php endif; ?>
                        <?php if($perumahan->telepon): ?><a href="tel:<?php echo e($perumahan->telepon); ?>" class="rounded-full border border-line bg-white px-5 py-3 text-sm font-black text-ink">Telepon</a><?php endif; ?>
                        <?php if($perumahan->email): ?><a href="mailto:<?php echo e($perumahan->email); ?>" class="rounded-full border border-line bg-white px-5 py-3 text-sm font-black text-ink">Email</a><?php endif; ?>
                        <?php if($perumahan->website_url): ?><a href="<?php echo e($perumahan->website_url); ?>" target="_blank" class="rounded-full border border-line bg-white px-5 py-3 text-sm font-black text-ink">Link Informasi</a><?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($perumahan->images->count() > 1): ?>
                <section class="rounded-[2rem] border border-line bg-white p-6 shadow-zenit">
                    <h2 class="text-xl font-black">Galeri Perumahan</h2>
                    <div class="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                        <?php $__currentLoopData = $perumahan->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('storage/' . $image->path)); ?>" class="h-56 w-full rounded-2xl object-cover" alt="<?php echo e($perumahan->nama); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>

            <section class="rounded-[2rem] border border-line bg-white p-6 shadow-zenit">
                <h2 class="text-xl font-black">Peta Lokasi</h2>
                <div id="detail-map" class="detail-map mt-5 rounded-[1.5rem]"></div>
            </section>
        </main>
        <aside class="space-y-6">
            <section class="rounded-[2rem] border border-line bg-white p-6 shadow-zenit">
                <h2 class="text-xl font-black">Informasi Lengkap</h2>
                <dl class="mt-5 grid gap-4 text-sm">
                    <div><dt class="font-black text-slate-400">Status</dt><dd class="mt-1 font-bold"><?php echo e($statusLabel); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Jenis Perumahan</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->jenis_perumahan ?: '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Jumlah Unit</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->jumlah_unit ?: '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Luas</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->luas ? $perumahan->luas . ' ha' : '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Harga Minimum</dt><dd class="mt-1 font-bold text-blue-600"><?php echo e($rupiah($perumahan->harga_min)); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Harga Maksimum</dt><dd class="mt-1 font-bold text-blue-600"><?php echo e($rupiah($perumahan->harga_max)); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Alamat</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->alamat ?: '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Kelurahan/Desa</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->kelurahan ?: '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Kecamatan</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->kecamatan ?: '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Kabupaten/Provinsi</dt><dd class="mt-1 font-bold"><?php echo e(trim(($perumahan->kabupaten ?: '-') . ', ' . ($perumahan->provinsi ?: '-'), ', ')); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Koordinat</dt><dd class="mt-1 font-mono text-xs font-bold"><?php echo e($perumahan->latitude); ?>, <?php echo e($perumahan->longitude); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Telepon</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->telepon ?: '-'); ?></dd></div>
                    <div><dt class="font-black text-slate-400">Email</dt><dd class="mt-1 font-bold"><?php echo e($perumahan->email ?: '-'); ?></dd></div>
                </dl>
            </section>
            <section class="rounded-[2rem] border border-line bg-white p-6 shadow-zenit">
                <h2 class="text-xl font-black">Risiko Terkait</h2>
                <div class="mt-4 space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $perumahan->risikos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $risiko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="rounded-2xl border border-line bg-soft p-4">
                            <p class="font-black"><?php echo e($risiko->nama_risiko); ?></p>
                            <p class="mt-1 text-xs font-bold uppercase tracking-wider text-slate-500"><?php echo e($risiko->tipe ?: 'Tipe tidak diisi'); ?> · <?php echo e(ucfirst($risiko->tingkat)); ?></p>
                            <p class="mt-2 text-sm leading-6 text-slate-600"><?php echo e($risiko->deskripsi ?: 'Deskripsi risiko belum tersedia.'); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="rounded-2xl bg-soft p-4 text-sm font-semibold text-slate-500">Belum ada risiko tercatat untuk perumahan ini.</p>
                    <?php endif; ?>
                </div>
            </section>
            <?php if(!empty($perumahan->fasilitas)): ?>
                <section class="rounded-[2rem] border border-line bg-white p-6 shadow-zenit"><h2 class="text-xl font-black">Fasilitas</h2><div class="mt-4 flex flex-wrap gap-2"><?php $__currentLoopData = $perumahan->fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fasilitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="rounded-full bg-soft px-3 py-1.5 text-xs font-black text-slate-700"><?php echo e($fasilitas); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></section>
            <?php endif; ?>
        </aside>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const lat = Number(<?php echo json_encode($perumahan->latitude, 15, 512) ?>); const lng = Number(<?php echo json_encode($perumahan->longitude, 15, 512) ?>); const name = <?php echo json_encode($perumahan->nama, 15, 512) ?>; const mapsUrl = <?php echo json_encode($mapsUrl, 15, 512) ?>;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    const map = L.map('detail-map').setView([lat, lng], 16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
    const icon = L.divIcon({ className: '', html: '<div class="zenit-marker active"></div>', iconSize: [24,24], iconAnchor: [12,12], popupAnchor: [0,-15] });
    L.marker([lat, lng], { icon }).addTo(map).bindPopup(`<div class="space-y-2"><p class="font-black">${name}</p>${mapsUrl ? `<a href="${mapsUrl}" target="_blank" class="block rounded-full bg-blue-600 px-3 py-2 text-center text-xs font-black text-white">Buka Google Maps</a>` : ''}</div>`).openPopup();
    setTimeout(() => map.invalidateSize(), 250);
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mypc\Desktop\Joki\Ripal\Laravel\resources\views/public/show.blade.php ENDPATH**/ ?>
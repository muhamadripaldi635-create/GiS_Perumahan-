<?php

namespace App\Http\Controllers;

use App\Models\Perumahan;
use Illuminate\View\View;

class PublicController extends Controller
{
    public function index(): View
    {
        $perumahans = Perumahan::with(['images', 'risikos'])->latest()->get();
        $kecamatans = $perumahans->pluck('kecamatan')->filter()->unique()->sort()->values();

        return view('public.home', compact('perumahans', 'kecamatans'));
    }

    public function show(Perumahan $perumahan): View
    {
        $perumahan->load(['images', 'risikos']);

        return view('public.show', compact('perumahan'));
    }
}

<?php

use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\AdminLaporanController;
use App\Http\Controllers\AdminPerumahanController;
use App\Http\Controllers\AdminRisikoController;
use App\Http\Controllers\PublicController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PublicController::class, 'index'])->name('home');
Route::get('/perumahan/{perumahan:slug}', [PublicController::class, 'show'])->name('perumahan.show');

Route::get('/login', fn () => redirect()->route('login'));
Route::get('/admin/login', [AdminAuthController::class, 'showLogin'])->middleware('guest')->name('login');
Route::post('/admin/login', [AdminAuthController::class, 'login'])->middleware('guest')->name('admin.login.submit');
Route::post('/admin/logout', [AdminAuthController::class, 'logout'])->middleware('auth')->name('admin.logout');

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', fn () => redirect()->route('admin.dashboard'));
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
    Route::resource('perumahans', AdminPerumahanController::class)->except(['show']);
    Route::resource('risikos', AdminRisikoController::class)->except(['show']);
    Route::get('/laporan', [AdminLaporanController::class, 'index'])->name('laporan.index');
    Route::get('/laporan/export', [AdminLaporanController::class, 'exportCsv'])->name('laporan.export');
});
